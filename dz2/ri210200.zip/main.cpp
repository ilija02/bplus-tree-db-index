#include "Helpers.h"

int main() {
	helpers::mainLoop();
	return 0;
}